﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_EF
{
    class Enrollment
    {
        [Key]
        public int id { get; set; }
        public int StudentId;
        [ForeignKey("StudentId")]
        public Student Student { get; set; }

        public int CourseId;
        [ForeignKey("CourseId")]
        public Course Course { get; set; }

    }
}
