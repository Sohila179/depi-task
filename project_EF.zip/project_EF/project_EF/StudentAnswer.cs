﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_EF
{
    class StudentAnswer
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(2000)]
        public string AnswerText { get; set; }
        [RegularExpression("^[ABCD]$", ErrorMessage = "CorrectOption must be A, B, C, or D")]
        [Column(TypeName = "char(1)")]
        public string? SelectedOption { get; set; }
        public bool? BooleanAnswer { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? MarksObtained { get; set; }

        [Required]
        [Column(TypeName = "date")]
        public DateTime SubmittedAt { get; set; }

        public int QuestionId;
        [ForeignKey("QuestionId")]
        public Question Question { get; set; }

        public int ExamAttemptId;
        [ForeignKey("ExamAttemptId")]
        public ExamAttempt ExamAttempt { get; set; }

    }
}
