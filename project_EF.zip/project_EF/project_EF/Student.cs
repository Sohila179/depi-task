﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_EF
{
    class Student
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [MaxLength(20)]
        public String StudentNumber { get; set; }
        [Required]
        [Column(TypeName = "date")]

        public DateTime EnrollmentDate { get; set; }
        public bool IsActive { get; set; } = true;
        public List<ExamAttempt> examAttempts { get; set; } = new List<ExamAttempt>();
        public List<Enrollment> enrollmentstudent { get; set; } = new List<Enrollment>();
    }
}
