﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_EF
{
    class Instructor
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [MaxLength(150)]
        public String Specialization { get; set; }
        [Required]
        [Column(TypeName = "date")]
        public DateTime HireDate { get; set; }
        public bool IsActive { get; set; } = true;
        public List<Teaching> instructorteaching { get; set; } = new List<Teaching>();
        public List<Exam> Exams { get; set; } = new List<Exam>();

    }
}
