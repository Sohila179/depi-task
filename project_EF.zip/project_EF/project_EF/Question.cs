﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_EF
{
    class Question
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(1000)]
        public string QuestionText { get; set; }
        
        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Marks { get; set; }
        public enum QuestionType
        {
            MultipleChoice,
            TrueFalse,
            Essay
        }
        [Required]
        [Column(TypeName = "date")]

        public DateTime CreatedDate { get; set; }

        public int ExamId;
        [ForeignKey("ExamId")]
        public Exam Exam { get; set; }
        public List<StudentAnswer> Q_studentAnswers = new List<StudentAnswer>();

    }
}
