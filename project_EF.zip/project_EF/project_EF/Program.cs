﻿using project_EF;
using Microsoft.EntityFrameworkCore;
using System.Collections;
using System.Collections.Immutable;
using System.Numerics;
using static System.Reflection.Metadata.BlobBuilder;

namespace project_EF
{
    internal class Program
    {
        static void Main(string[] args)
        {

           
        }
    }
}
