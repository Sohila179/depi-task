﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_EF
{
    class Exam
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(200)]
        public string  Title { get; set; }
        [MaxLength(500)]
        public string Description { get; set; }
        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalMarks { get; set; }
        [Required]
        [Column(TypeName = "time")]
        public TimeSpan Duration { get; set; }
        [Required]
        [Column(TypeName = "date")]
        public DateTime StartDate { get; set; }
        [Required]
        [Column(TypeName = "date")]
        public DateTime EndDate { get; set; }
        public bool IsActive { get; set; } = true;
        public int InstructorId;
        [ForeignKey("InstructorId")]
        public Instructor Instructor { get; set; }

        public int CourseId;
        [ForeignKey("CourseId")]
        public Course Course { get; set; }
         public List<Question> Questions { get; set; } = new List<Question>();
    }
}
