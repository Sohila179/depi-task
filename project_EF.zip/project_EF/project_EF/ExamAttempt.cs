﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_EF
{
    class ExamAttempt
    {
        [Key]
        public int Id { get; set; }
       
        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal? TotalScore { get; set; }
      
        [Required]
        [Column(TypeName = "date")]
        public DateTime StartTime { get; set; }
        [Required]
        [Column(TypeName = "date")]
        public DateTime EndTime { get; set; }
        public bool IsGraded { get; set; } = false;
        public bool IsSubmitted { get; set; } = false;
        public int StudentId;
        [ForeignKey("StudentId")]
        public Student Student { get; set; }
        public int ExamId;
        [ForeignKey("ExamId")]
        public Exam Exam { get; set; }

        public List<StudentAnswer> ex_studentAnswers = new List<StudentAnswer>();

    }
}
