﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace project_EF
{
    class ExaminationDbContext : DbContext 
    {
        
        public DbSet<Course>courses { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
        public DbSet<EssayQuestion> essayQuestions { get; set; }
        public DbSet<Exam> Exams { get; set; }
        public DbSet<ExamAttempt> ExamAttempts { get; set; }
        public DbSet<Instructor> instructors { get; set; }
        public DbSet<MultipleChoiceQuestion> multipleChoiceQuestions { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<StudentAnswer> studentAnswers { get; set; }
        public DbSet<Teaching> teachings { get; set; }
        public DbSet<TrueFalseQuestion> trueFalseQuestions { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)

        {
            optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=ExaminatinSystem;Trusted_Connection=True;Integrated Security=True;Encrypt=False;");


        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Enrollment>(e =>
            {
                e.HasKey(e => new { e.StudentId, e.CourseId });
            });

            modelBuilder.Entity<Teaching>(t =>
            {
                t.HasKey(t => new { t.InstructorId, t.CourseId });
            });
            modelBuilder.Entity<Student>(s =>
            {
                s.HasIndex(s => s.Email).IsUnique();
                s.HasIndex(s => s.StudentNumber).IsUnique();
            });
            modelBuilder.Entity<Instructor>(i =>
            {
                i.HasIndex(i => i.Email).IsUnique();
            });
            modelBuilder.Entity<Exam>()
                .HasOne(E => E.Course)
                .WithMany(c => c.Exams)
                .HasForeignKey(e => e.CourseId)
                 .OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Question>()
                .HasOne(q => q.Exam)
                .WithMany(e => e.Questions)
                .HasForeignKey(q => q.ExamId)
                .OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<StudentAnswer>()
                .HasOne(st=>st.ExamAttempt)
                .WithMany(ex=>ex.ex_studentAnswers)
                .HasForeignKey(st=>st.ExamAttemptId)
                .OnDelete(DeleteBehavior.Cascade);
            modelBuilder.Entity<ExamAttempt>()
                .HasOne(e => e.Student)
                .WithMany(s => s.examAttempts)
                .HasForeignKey(e => e.StudentId)
                .OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Exam>()
                   .HasCheckConstraint("CK_Exam_Date", "[StartDate] < [EndDate]");

            modelBuilder.Entity<Question>()
                  .HasCheckConstraint("CK_ques_mark", "[Marks] > 0");
            modelBuilder.Entity<Course>()
               .HasCheckConstraint("CK_course_maxdegree", "[MaximumDegree] > 0");

            modelBuilder.Entity<Exam>()
                .HasIndex(e => e.StartDate);
            modelBuilder.Entity<ExamAttempt>()
              .HasIndex(e => e.StartTime);
            modelBuilder.Entity<Question>()
                 .HasDiscriminator<string>("QuestionType")     
                 .HasValue<EssayQuestion>("Essay")           
                 .HasValue<MultipleChoiceQuestion>("MultipleChoice")      
                 .HasValue<TrueFalseQuestion>("TrueFalse");
            modelBuilder.Entity<Course>().HasData(
     new Course { Id = 1, Title = "Mathematics", Description = "Math Course", MaximumDegree = 100 },
     new Course { Id = 2, Title = "Physics", Description = "Physics Course", MaximumDegree = 100 },
     new Course { Id = 3, Title = "Programming", Description = "Programming Course", MaximumDegree = 100 }
 );



            modelBuilder.Entity<Instructor>().HasData(
              new Instructor
              {
                  Id = 1,
                  Name = "Dr. Ahmed Ali",
                  Email = "ahmed.ali@example.com",
                  Specialization = "Mathematics",
                  HireDate = new DateTime(2020, 9, 1),
                  IsActive = true
              },
              new Instructor
              {
                  Id = 2,
                  Name = "Dr. Sarah Hassan",
                  Email = "sarah.hassan@example.com",
                  Specialization = "Physics",
                  HireDate = new DateTime(2021, 2, 15),
                  IsActive = true
              }
          );

            modelBuilder.Entity<Student>().HasData(
                new Student { Id = 1, Name = "Ali", Email = "ali@mail.com", StudentNumber = "S001" },
                new Student { Id = 2, Name = "Sara", Email = "sara@mail.com", StudentNumber = "S002" },
                new Student { Id = 3, Name = "Omar", Email = "omar@mail.com", StudentNumber = "S003" },
                new Student { Id = 4, Name = "Nora", Email = "nora@mail.com", StudentNumber = "S004" },
                new Student { Id = 5, Name = "Mona", Email = "mona@mail.com", StudentNumber = "S005" }
            );

            modelBuilder.Entity<Exam>().HasData(
               new Exam
               {
                   Id = 1,
                   Title = "Math Midterm",
                   Description = "Midterm Exam for Mathematics",
                   TotalMarks = 100,
                   Duration = TimeSpan.FromHours(2),
                   StartDate = DateTime.Parse("2025-01-10"),
                   EndDate = DateTime.Parse("2025-01-11"),
                   InstructorId = 1,
                   CourseId = 1
               },
               new Exam
               {
                   Id = 2,
                   Title = "Physics Final",
                   Description = "Final Exam for Physics",
                   TotalMarks = 100,
                   Duration = TimeSpan.FromHours(3),
                   StartDate = DateTime.Parse("2025-01-15"),
                   EndDate = DateTime.Parse("2025-01-16"),
                   InstructorId = 2,
                   CourseId = 2
               }
           );





        }


    }
    }
