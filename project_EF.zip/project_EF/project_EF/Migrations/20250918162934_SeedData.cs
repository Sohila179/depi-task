﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace project_EF.Migrations
{
    /// <inheritdoc />
    public partial class SeedData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "Id", "Email", "EnrollmentDate", "IsActive", "Name", "StudentNumber" },
                values: new object[,]
                {
                    { 1, "ali@mail.com", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Ali", "S001" },
                    { 2, "sara@mail.com", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Sara", "S002" },
                    { 3, "omar@mail.com", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Omar", "S003" },
                    { 4, "nora@mail.com", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Nora", "S004" },
                    { 5, "mona@mail.com", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Mona", "S005" }
                });

            migrationBuilder.InsertData(
                table: "courses",
                columns: new[] { "Id", "CreatedDate", "Description", "IsActive", "MaximumDegree", "Title" },
                values: new object[,]
                {
                    { 1, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Math Course", true, 100m, "Mathematics" },
                    { 2, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Physics Course", true, 100m, "Physics" },
                    { 3, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Programming Course", true, 100m, "Programming" }
                });

            migrationBuilder.InsertData(
                table: "instructors",
                columns: new[] { "Id", "Email", "HireDate", "IsActive", "Name", "Specialization" },
                values: new object[,]
                {
                    { 1, "ahmed.ali@example.com", new DateTime(2020, 9, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Dr. Ahmed Ali", "Mathematics" },
                    { 2, "sarah.hassan@example.com", new DateTime(2021, 2, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), true, "Dr. Sarah Hassan", "Physics" }
                });

            migrationBuilder.InsertData(
                table: "Exams",
                columns: new[] { "Id", "CourseId", "Description", "Duration", "EndDate", "InstructorId", "IsActive", "StartDate", "Title", "TotalMarks" },
                values: new object[,]
                {
                    { 1, 1, "Midterm Exam for Mathematics", new TimeSpan(0, 2, 0, 0, 0), new DateTime(2025, 1, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), 1, true, new DateTime(2025, 1, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Math Midterm", 100m },
                    { 2, 2, "Final Exam for Physics", new TimeSpan(0, 3, 0, 0, 0), new DateTime(2025, 1, 16, 0, 0, 0, 0, DateTimeKind.Unspecified), 2, true, new DateTime(2025, 1, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Physics Final", 100m }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Exams",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Exams",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "courses",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "courses",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "courses",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "instructors",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "instructors",
                keyColumn: "Id",
                keyValue: 2);
        }
    }
}
