﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_EF
{
    class Teaching
    {
        [Key]
        public int id { get; set; }

        public int InstructorId;
        [ForeignKey("InstructorId")]
        public Instructor Instructor { get; set; }

        public int CourseId;
        [ForeignKey("CourseId")]
        public Course Course { get; set; }
        [Required]
        [Column(TypeName = "date")]

        public DateTime AssignedDate { get; set; }
        public bool IsActive { get; set; } = true;

    }
}
