﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace project_EF
{
    class Course
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(200)]
        public string Title { get; set; }
        [MaxLength(1000)]
        public string Description { get; set; }
        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal MaximumDegree { get; set; }
        [Required]
        [Column(TypeName = "date")]

        public DateTime CreatedDate { get; set; }
        public bool IsActive { get; set; } = true;

        public List<Enrollment> enrollmentcourse { get; set; } = new List<Enrollment>();
        public List<Teaching> courseteaching { get; set; } = new List<Teaching>();

        public List<Exam> Exams { get; set; } = new List<Exam>();


    }
}
